﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace adesso_XTB_Plugins.DocumentTemplateExport.Exceptions
{
    public class InvalidDirectoryException : Exception
    {
        public InvalidDirectoryException()
        {
        } 
    }
}
